<!DOCTYPE html>
<html>
<head>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            margin: 0;
        }

        .container {
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        h2 {
            color: #333;
            margin: 0 0 15px;
        }
        label {
            display: block;
            margin-bottom: 5px;
        }

        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 3px;
            padding-right: 0;
        }
        hr {
            border: 0;
            border-top: 1px solid #ccc;
            margin: 15px 0;
        }

        button {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 10px 20px;
            cursor: pointer;
        }

        #userList {
            margin-top: 20px;
            border-top: 1px solid #ccc;
            padding-top: 10px;
        }
    </style>
    <script type="text/javascript">
        function showUserList() {
            var dbHost = document.getElementById("dbHost").value;

            var xhr = new XMLHttpRequest();
            xhr.onreadystatechange = function () {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    document.getElementById("userList").innerHTML = xhr.responseText;
                }
            };
            xhr.open("GET", "get_user_list.php?dbHost=" + dbHost, true);
            xhr.send();
        }

        function addUser() {
            var dbHost = document.getElementById("dbHost").value;

            var xhr = new XMLHttpRequest();
            xhr.onreadystatechange = function () {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    document.getElementById("addUserResult").innerHTML = xhr.responseText;
                }
            };
            xhr.open("POST", "add_user.php", true);
            xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            xhr.send("dbHost=" + dbHost);
        }
    </script>
</head>
<body>
    <div class="container">
        <h5>카카오클라우드</h5>
        <p></p>

        <?php
        $ip_address = $_SERVER['REMOTE_ADDR'];
        echo "<h3>당신의 IP 주소는: " . $ip_address . "</h3>";

        $HOST_NAME = ($_ENV['HOSTNAME']) ? $_ENV['HOSTNAME'] : php_uname('n');
        echo "<h3>호스트명: " . $HOST_NAME . "</h3>";
        ?>

        <p></p>
        <hr>
        <p></p>

        <h3>데이터베이스 연결 정보</h3>
        <label for="dbHost">호스트:</label>
        <input type="text" id="dbHost" name="dbHost">

        <button onclick="showUserList()">유저 이름 가져오기</button>
        <div id="userList"></div>

        <p></p>

        <h3>새로운 사용자 추가</h3>
        <label for="newUsername">새로운 유저 이름:</label>
        <button onclick="addUser()">유저 추가</button>
        <div id="addUserResult"></div>
    </div>
</body>
</html>



